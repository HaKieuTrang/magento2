<?php
namespace Magenest\CustomerAttribute\Setup;

use Magento\Customer\Model\Customer;
use Magento\Customer\Setup\CustomerSetupFactory;
use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Eav\Model\Entity\Attribute\SetFactory as AttributeSetFactory;

class InstallData implements InstallDataInterface{
    private $customerSetupFactory;
    protected $attributeSetFactory;
    public function __construct(\Magento\Customer\Setup\CustomerSetupFactory $customerSetupFactory, AttributeSetFactory $attribute)
    {
        $this->customerSetupFactory = $customerSetupFactory;
        $this->attributeSetFactory  = $attribute;
    }

    public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $customerSetup = $this->customerSetupFactory->create(['setup' => $setup]);
        $customerEntity = $customerSetup->getEavConfig()->getEntityType('customer');
        $attributeSetId = $customerEntity->getDefaultAttributeSetId();
        $attributeSet = $this->attributeSetFactory->create();
        $attributeGroupId = $attributeSet->getDefaultGroupId($attributeSetId);
        $customerSetup->removeAttribute(Customer::ENTITY, 'avatar');
        $customerSetup->addAttribute(\Magento\Customer\Model\Customer::ENTITY, 'avatar', [
            'type' => 'varchar',
            'backend' => 'Magenest\CustomerAttribute\Model\Customer\Attribute\Backend\Avatar',
            'label' => 'Upload Avatar',
            'input' => 'image',
            'required' => false,
            'visible' => true,
            'position' => 210,
            'system' => true,
            'user_defined' => true,
        ]);

        $image = $customerSetup->getEavConfig()->getAttribute('customer', 'avatar')
            ->addData([
                'attribute_set_id' => $attributeSetId,
                'attribute_group_id' =>$attributeGroupId,
                'used_in_forms' => ['adminhtml_customer', 'customer_account_create', 'customer_account_edit'],
            ])->save();

    }
}
