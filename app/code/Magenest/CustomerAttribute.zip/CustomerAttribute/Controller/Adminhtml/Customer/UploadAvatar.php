<?php


namespace Magenest\CustomerAttribute\Controller\Adminhtml\Customer;


class UploadAvatar
{

}